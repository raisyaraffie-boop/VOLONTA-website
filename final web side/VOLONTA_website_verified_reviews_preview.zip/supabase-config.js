window.VOLONTA_SUPABASE_CONFIG = {
  // Isi dengan Project URL dan Publishable key dari Supabase.
  // Gunakan hanya sb_publishable_... (atau anon key lama), jangan pernah sb_secret/service_role.
  url: "https://YOUR_PROJECT.supabase.co",
  publishableKey: "YOUR_PUBLISHABLE_KEY"
};
