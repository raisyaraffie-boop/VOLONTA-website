# VOLONTÀ — Wear the Time

Website statis untuk GitHub Pages. Foto tersedia di `assets/`.

## Ulasan pembeli (memerlukan Supabase)

Ulasan publik memakai Supabase. Pengunjung dapat membaca ulasan yang sudah dikirim; pembeli mengirim ulasan dengan kode sekali pakai yang dibuat admin setelah pesanan diterima.

1. Buat project Supabase.
2. Jalankan `supabase/schema.sql` lewat Supabase Dashboard → SQL Editor.
3. Deploy Edge Function `submit-review` dari folder `supabase/functions/submit-review`. Gunakan Supabase CLI: login, link project, lalu deploy function. Konfigurasi `supabase/config.toml` menonaktifkan verifikasi JWT gateway karena akses submit dilindungi kode pembeli sekali pakai; fungsi tetap menggunakan `SUPABASE_SERVICE_ROLE_KEY` hanya di server.
4. Isi `supabase-config.js` memakai Project URL dan **Publishable key** project. Publishable key memang untuk kode browser; jangan pernah menaruh Secret/service-role key di file ini.
5. Commit dan push perubahan ke GitHub. Pastikan GitHub Pages menerbitkan branch `main` dari `/(root)`.
6. Setelah pesanan diterima, admin jalankan di SQL Editor, misalnya `select public.issue_review_code('denim', 'ORD-001');`. Kirim kode yang keluar kepada pembeli melalui WhatsApp. Gunakan product key `denim`, `blouson`, atau `leather` yang sesuai pesanan.

Tabel review code tidak dapat dibaca publik. Review code memiliki 8-byte nilai acak, disimpan sebagai hash, hanya cocok untuk produk yang dipesan, dan otomatis habis setelah satu kali dipakai. Ulasan disimpan sebagai publik dan ditampilkan pada website.

## Fitur website

- Desain Dark Luxury responsif, katalog produk, panduan ukuran S–XL, keranjang, dan checkout WhatsApp.
- Pengiriman, retur/refund, Hard Box, Certificate Artist Edition, kontak Instagram dan email.
- Ulasan bersama lintas pengunjung setelah Supabase dikonfigurasi.

Estimasi ukuran dan kebijakan layanan di halaman merupakan draf yang perlu ditinjau sebelum dipublikasikan.
