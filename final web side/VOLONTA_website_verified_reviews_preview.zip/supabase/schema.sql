-- VOLONTA public reviews with single-use verified-purchase codes.
-- Run this file in Supabase Dashboard > SQL Editor as the project owner.

create extension if not exists pgcrypto with schema extensions;

create table if not exists public.reviews (
  id uuid primary key default gen_random_uuid(),
  reviewer_name text not null check (char_length(reviewer_name) between 1 and 60),
  product_key text not null check (product_key in ('denim', 'blouson', 'leather')),
  rating smallint not null check (rating between 1 and 5),
  body text not null check (char_length(body) between 1 and 1200),
  status text not null default 'approved' check (status in ('approved', 'hidden')),
  created_at timestamptz not null default now()
);

create table if not exists public.review_codes (
  id uuid primary key default gen_random_uuid(),
  code_hash text not null unique,
  product_key text not null check (product_key in ('denim', 'blouson', 'leather')),
  order_reference text not null,
  used_at timestamptz,
  created_at timestamptz not null default now()
);

alter table public.reviews enable row level security;
alter table public.review_codes enable row level security;

revoke all on table public.reviews from public, anon, authenticated;
grant select on table public.reviews to anon, authenticated;
drop policy if exists "Anyone can read approved reviews" on public.reviews;
create policy "Anyone can read approved reviews"
  on public.reviews for select
  to anon, authenticated
  using (status = 'approved');

revoke all on table public.review_codes from public, anon, authenticated, service_role;

create or replace function public.submit_verified_review(
  p_code_hash text,
  p_reviewer_name text,
  p_product_key text,
  p_rating smallint,
  p_body text
) returns uuid
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_code public.review_codes%rowtype;
  v_review_id uuid;
begin
  select * into v_code
    from public.review_codes
    where code_hash = p_code_hash and used_at is null
    for update;

  if not found or v_code.product_key <> p_product_key then
    raise exception 'invalid_or_used_code';
  end if;

  insert into public.reviews (reviewer_name, product_key, rating, body, status)
  values (trim(p_reviewer_name), p_product_key, p_rating, trim(p_body), 'approved')
  returning id into v_review_id;

  update public.review_codes set used_at = now() where id = v_code.id;
  return v_review_id;
end;
$$;

revoke all on function public.submit_verified_review(text, text, text, smallint, text) from public, anon, authenticated;
grant execute on function public.submit_verified_review(text, text, text, smallint, text) to service_role;

-- Run this only from the Supabase SQL Editor after confirming an order was delivered.
-- The returned code is shown once. Send it to that buyer via WhatsApp.
create or replace function public.issue_review_code(p_product_key text, p_order_reference text)
returns text
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_code text := upper(encode(extensions.gen_random_bytes(8), 'hex'));
begin
  if p_product_key not in ('denim', 'blouson', 'leather') then
    raise exception 'invalid_product_key';
  end if;
  if coalesce(trim(p_order_reference), '') = '' then
    raise exception 'order_reference_required';
  end if;

  insert into public.review_codes (code_hash, product_key, order_reference)
  values (encode(extensions.digest(convert_to(v_code, 'UTF8'), 'sha256'), 'hex'), p_product_key, trim(p_order_reference));
  return v_code;
end;
$$;

revoke all on function public.issue_review_code(text, text) from public, anon, authenticated, service_role;


