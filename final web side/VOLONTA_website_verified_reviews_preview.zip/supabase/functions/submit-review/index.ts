import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Content-Type": "application/json",
};
const validProducts = new Set(["denim", "blouson", "leather"]);
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: corsHeaders });

async function hashCode(code: string): Promise<string> {
  const data = new TextEncoder().encode(code.trim().toUpperCase());
  const digest = await crypto.subtle.digest("SHA-256", data);
  return Array.from(new Uint8Array(digest), byte => byte.toString(16).padStart(2, "0")).join("");
}

Deno.serve(async request => {
  if (request.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });
  if (request.method !== "POST") return json({ error: "Metode tidak didukung." }, 405);

  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!supabaseUrl || !serviceKey) return json({ error: "Fungsi belum dikonfigurasi oleh admin." }, 500);

  let input: Record<string, unknown>;
  try { input = await request.json(); } catch { return json({ error: "Data ulasan tidak valid." }, 400); }

  const code = typeof input.code === "string" ? input.code.trim().toUpperCase() : "";
  const name = typeof input.name === "string" ? input.name.trim() : "";
  const product = typeof input.product === "string" ? input.product : "";
  const rating = Number(input.rating);
  const body = typeof input.body === "string" ? input.body.trim() : "";
  if (!/^[A-F0-9]{16}$/.test(code) || name.length < 1 || name.length > 60 || !validProducts.has(product) || !Number.isInteger(rating) || rating < 1 || rating > 5 || body.length < 1 || body.length > 1200) {
    return json({ error: "Lengkapi data ulasan dengan benar." }, 400);
  }

  const response = await fetch(`${supabaseUrl}/rest/v1/rpc/submit_verified_review`, {
    method: "POST",
    headers: {
      "apikey": serviceKey,
      "Authorization": `Bearer ${serviceKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      p_code_hash: await hashCode(code),
      p_reviewer_name: name,
      p_product_key: product,
      p_rating: rating,
      p_body: body,
    }),
  });

  if (!response.ok) {
    const errorText = await response.text();
    if (errorText.includes("invalid_or_used_code")) return json({ error: "Kode salah, sudah dipakai, atau tidak cocok dengan produk." }, 400);
    return json({ error: "Ulasan belum berhasil dikirim. Coba lagi nanti." }, 500);
  }
  return json({ ok: true });
});
