window.VOLONTA_SUPABASE_CONFIG = {
  // Isi Project URL dan Publishable key dari pengaturan API Supabase.
  // Publishable key boleh ada di website publik jika RLS di database aktif.
  // Jangan pernah menaruh Secret/service-role key di file website.
  url: "https://YOUR_PROJECT.supabase.co",
  publishableKey: "YOUR_PUBLISHABLE_KEY"
};
